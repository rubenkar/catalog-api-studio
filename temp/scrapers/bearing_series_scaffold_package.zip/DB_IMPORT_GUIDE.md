# Bearing series scaffold for DB import

## Package purpose
This package contains a **broad list of common bearing series** across DIN / ISO / JIS / GOST.
Inside each series there are **2–4 representative models**.

This is designed as a **database import scaffold**.

## Counts
- Families: 2
- Types: 20
- Series: 82
- Models: 246

## Tree structure
- `families`
  - `types`
    - `series`
      - `models`

## Dictionaries
- `type_dictionary`
- `execution_dictionary`
- `match_type_dictionary`

## Model structure
```json
{
  "model": "6205",
  "size": {
    "d": 25,
    "D": 52,
    "B": 15
  },
  "model_standard": {
    "DIN": "6205",
    "ISO": "6205",
    "JIS": "6205"
  },
  "cross_standard_analogs": [
    {
      "standard": "GOST",
      "code": "205",
      "match_type_id": 1
    }
  ],
  "execution_ids": [1, 7, 9]
}
```

## Recommended DB tables
- `bearing_families`
- `bearing_types`
- `bearing_series`
- `bearing_models`
- `bearing_model_standard_codes`
- `bearing_model_analogs`
- `bearing_model_execution_links`
- `execution_dictionary`
- `match_type_dictionary`

## Import notes
1. Load dictionaries first.
2. Insert families.
3. Insert types by `type_id`.
4. Insert series.
5. Insert models.
6. Expand `model_standard` into a child table if needed.
7. Expand `cross_standard_analogs` into a child table.
8. Link `execution_ids` to `execution_dictionary`.

## Important note
This is **not** a literal complete market inventory of all commercial SKUs.
It is a **maximally broad starter tree of series**, with representative models per series.
