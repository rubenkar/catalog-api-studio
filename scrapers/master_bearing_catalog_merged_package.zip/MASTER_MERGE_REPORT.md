# Master catalog merge report

## Sources
- `bearing_catalog_fixed_standards.json`
- `supplier_tree_technical_only.json`

## Merge result
- Families: 13
- Types: 46
- Series: 216
- Models: 1713

## Merge rules
- Technical dedupe key:
  - family
  - type
  - series
  - model
  - size fields (`d`, `D`, `B`, `T`)
- On duplicate merge:
  - `execution_ids` are unioned
  - `model_standard` is unioned
  - `cross_standard_analogs` is unioned
- `source` field values:
  - `standards`
  - `supplier`
  - `both`

## Notes
- Supplier commercial data was not included.
- Supplier `source_category_path` was preserved when available.
- Family, type, execution and match type dictionaries were normalized and remapped.
